<!DOCTYPE html>
<html>
<head>
<style>
body{
  background-image: url('it2.PNG');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
#button {
width:100px;
height:50px;
border:0px;
background-color:#006e6b;
border-radius:15px;
color:white;
font-size:20px;
}
</style>
<script type="text/javascript">
function validateForm() {
  var x1 = document.forms["myForm"]["fname"].value;
  var x2 = document.forms["myForm"]["lname"].value;
  var x3 = document.forms["myForm"]["mail"].value;
  var x4 = document.forms["myForm"]["country"].value;
  var x5 = document.forms["myForm"]["password"].value;

  if (x1 == "" ) {
    alert(" fname must be filled out");
    return false;
  }

  if (x2 == "" ) {
    alert("last Name must be filled out");
    return false;
  }
  if (x3 == "" ) {
    alert("mail must be filled out");
    return false;
  }
  if (x4 == "" ) {
    alert("country must be filled out");
    return false;
  }
  if (x5 == "" ) {
    alert("password must be filled out");
    return false;
  }



}

</script>
</head>


<!--<body style="background-color:#009886;">-->

<form name="myForm"  onsubmit="return validateForm()" method="post">
<center><h1><font color="white">Sign Up</font></h1></center>
<hr>


<center><h2><font color="white">Please fill the information below</font></h2>
 <font color="white" >First Name:<br>
 </font> <input type="text" name="fname"><br><br>
 <font color="white">Last Name:</font>
<br>
<input type="text" name="lname"><br><br>
 <font color="white">E-mail:<br></font> <input type="mail" name="mail"><br><br>
 <font color="white">Country:<br></font> <input type="text" name="country"><br><br>
 <font color="white">Password:<br></font>  <input type="Password" name="password"><br><br>

 <!--Article category: <select name = "category">
 <option value="accidents" name="accidents"> accidents<br></option>
 <option value="arts" name="arts"><br> arts </option>
 <option value="sports" name="sports"><br></option>
 </select>
 <br>
 Article Date: <input type="date" name="date" ><br>
 <br><br>
 Article Description <br><center><textarea name="des" rows = "10" cols = "50" ></textarea></center>
<br><br><br>-->

 <br>
  <center><input type="submit" name='submit' value="Sign Up" id ="button"></center>
</form>

<?php
if (isset($_POST['submit'])) {

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mail = $_POST['mail'];
    $country = $_POST['country'];
    $p = $_POST['password'];

    $servername = "localhost";
    $username = "root";
    $password = "as@ah221999";
    $dname = "library";

    $conn = new mysqli($servername, $username, $password, $dname);
    if ($conn->connect_error) {
        die("Connection failed: ") . $conn->connect_error;
    } else {
        //echo "inserted";
    }

    $sql = "INSERT INTO `users`(`firstName`, `lastName`, `e-mail`, `country`, `password`) VALUES ('$fname','$lname','$mail','$country','$p')";
    if ($conn->query($sql) == true) {
        echo " suceess";
        // Start the session
        session_start();
        $_SESSION["email"] = $mail;
		header('location:bootstrp.php'); // redirect user to profile.php

    } else {
        echo "error" . $sql . "<br>" . $conn->error;
    }


    $conn->close();
}
?>

</body>
</html>
