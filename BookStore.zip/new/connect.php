<?php
$servername = "localhost";
$username = "root";
$password = "as@ah221999";
//$password = "";
$dname = "library";

$conn = new mysqli($servername, $username, $password, $dname);
if ($conn->connect_error) {
    die("Connection failed: ") . $conn->connect_error;
    exit();
}
