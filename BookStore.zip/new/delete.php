<!DOCTYPE html>
<?php 
session_start();
 include 'book.php';?>
<html>
<head>
<style>

body{
  background-image: url('it2.PNG');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}

h1{
color:white;
}

form {
align:center;
color:white;
}

#button {
width:100px;
height:50px;
border:0px;
background-color:#006e6b;
border-radius:15px;
color:white;
font-size:20px;


}


</style>

<script type="text/javascript">
function validateForm() {
  var x1 = document.forms["myForm"]["author"].value;
  var x2 = document.forms["myForm"]["bookName"].value;
  
  
  if (x1 == "" ) {
    alert("Author name must be filled out");
    return false;
  }

  if (x2 == "" ) {
    alert("Book name must be filled out");
    return false;
  }
	



}

</script>
</head>
<body>

<form name="myForm"  onsubmit="return validateForm()" method="post">
<center><h1>Delete Book</h1></center>
<hr>
 <center>Book Name:<br><br> <center><input type="text" name="bookName"></center><br></center>
<center>Author Name:<br><br> <center><input type = "text" name="author" ></center></center>


<br><br><br>


  <center><input type="submit" name = "submit" value="Delete" id="button"></center>
</form>

<?php
if (isset($_POST['submit'])){
	
$ob1 = new book();

$ob1->setName($_POST['bookName']);
$ob1->setAuthor($_POST['author']);

$var1 = $ob1->getName();
$var2 = $ob1->getAuthor();

session_start();

 $email = $_SESSION["email"];
echo "+++++++++++++++++++++++";
$servername = "localhost";
$username ="root";
$password ="as@ah221999";
$dname ="library";

$conn = new mysqli($servername, $username ,$password ,$dname);
if ($conn->connect_error){
    die ("Connection failed: ").$conn->connect_error;
}
else
{
    $sql = "Delete From `books` WHERE `bookname` = '$var1' AND `author` = '$var2' AND `email` = '$email'";
    if ($conn->query($sql)) {
        echo "Record Inserted successfully";
    }
     else {
        echo "Error Inserted record: " . $conn->error;
    }
    $conn->close();
}
}
?>


</body>
</html>