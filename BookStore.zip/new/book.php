<?php
class book{
	public $bname;
	public $category;
	public $author;
	public $price;
	
	function setName($bname){
		$this->bname = $bname;
	}
	function setCategory($category){
		$this->category = $category;
	}
	function setAuthor($author){
		$this->author = $author;
	}
	function setPrice($price){
		$this->price = $price;
	}
	function getName(){
		return $this->bname;
	}
	function getCategory(){
		return $this->category;
	}
	function getAuthor(){
		return $this->author;
	}
	function getPrice(){
		return $this->price;
	}
	
}
?>