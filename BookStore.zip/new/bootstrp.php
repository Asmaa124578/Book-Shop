<!DOCTYPE html>
<html lang="en">
<?php include 'book.php';?>

<head>

  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li><a href="homee.php">Home</a></li>
      <li><a href="add.php">Add Book</a></li>
      <li><a href="update.php">Update Book</a></li>
      <li><a href="delete.php">Delete Book</a></li>
      <li><a href="view.php">View Book</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      
	  <li><a href="homee.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
		
	</ul>
  </div>
</nav>
  
<style>
body{
  background-image: url('it2.PNG');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}

</style>
<?php
$name = $_POST['name'];
$category = $_POST['category'];
$author = $_POST['author'];
$price = $_POST['price'];


$servername = "localhost";
$username ="root";
$password ="as@ah221999";
$dname ="library";

$conn = new mysqli($servername, $username ,$password ,$dname);
if ($conn->connect_error){
	die ("Connection failed: ").$conn->connect_error;
}
else
{
	//echo "inserted";
}


$query = "SELECT * FROM `books`";
$result = mysqli_query($conn, $query);
$rownum = mysqli_num_rows($result);

echo '<center><table border="3" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">name</font> </td> 
          <td> <font face="Arial">category</font> </td> 
          <td> <font face="Arial">author</font> </td> 
          <td> <font face="Arial">price</font> </td> 
		  <td> <font face="Arial">email</font> </td> 
      </tr>';
    while ($rownum>0) {
		$row = mysqli_fetch_assoc($result);
        
        
        echo "<tr>";
		echo "<td>".$row["bookname"]."</td>";
		echo "<td>".$row["category"]."</td>";
		echo "<td>".$row["author"]."</td>";
		echo "<td>".$row["price"]."</td>";
		echo "<td>".$row["email"]."</td>";
                  
               
             echo "</tr> </center>"; 
	$rownum--;
    }
  
 
$conn->close();
	?>
</body>

</html>
