<!DOCTYPE html>
<html>
<?php 
session_start();
 include 'book.php';?>

<head>
<style>
body{
background-color: #009886;
}


h1{
color:white;
}

form {
align:center;
color:white;
}

#button {
width:100px;
height:50px;
border:0px;
background-color:#006e6b;
border-radius:15px;
color:white;
font-size:20px;


}

</style>

<script type="text/javascript">
function validateForm() {
  var x1 = document.forms["myForm"]["name"].value;
  var x2 = document.forms["myForm"]["author"].value;
  var x3 = document.forms["myForm"]["price"].value;
  
  if (x1 == "" ) {
    alert("Please enter book name");
    return false;
  }

  if (x2 == "" ) {
    alert("Please enter author name");
    return false;
  if (x3 == "" ) {
    alert("Please enter book price");
    return false;
  
  


}

</script>
</head>
<body>

<form name="myForm"  onsubmit="return validateForm()" method="post">
<center><h1>Add Book</h1></center>
<hr>
 <center>Book Name:<br><br> <center><input type="text" name="name"></center><br></center>
<center>Book Author:<br><br> <center><input type="text" name="author"></center><br></center>
<center>Book Price:<br><br> <center><input type="number_format" name="price"></center><br></center>
<center>Book Category:<br><br><select name = "category">
 <option value="Drama" name="Drama"><br> Drama<br></option>
 <option value="Action" name="Action"><br> Action </option>
 <option value="Fiction" name="Fiction"><br>Fiction</option>
 <option value="Fiction" name="Fiction"><br>History</option>
 <option value="Fiction" name="Fiction"><br>Novel</option>
 <option value="Fiction" name="Fiction"><br>Poetry</option>
 </select>

<br><br><br>


  <center><input type="submit" name = "submit" value="Add Book" id="button"></center>
</form>
<?php
if (isset($_POST['submit'])){
	
$ob1 = new book();

$ob1->setName($_POST['name']);
$ob1->setCategory($_POST['category']);
$ob1->setAuthor($_POST['author']);
$ob1->setPrice($_POST['price']);

$var1 = $ob1->getName();
$var2 = $ob1->getAuthor();
$var3 = $ob1->getCategory();
$var4 = $ob1->getPrice();
session_start();

 $email = $_SESSION["email"];
echo "+++++++++++++++++++++++";
$servername = "localhost";
$username ="root";
$password ="as@ah221999";
$dname ="library";

$conn = new mysqli($servername, $username ,$password ,$dname);
if ($conn->connect_error){
    die ("Connection failed: ").$conn->connect_error;
}
else
{
    $sql = "INSERT INTO `books`(`bookname`, `category`, `author`, `price`, `email`) VALUES ('$var1','$var3','$var2','$var4','$email')";
    if ($conn->query($sql)) {
        echo "Record Inserted successfully";
    }
     else {
        echo "Error Inserted record: " . $conn->error;
    }
    $conn->close();
}
}
?>

</body>
</html>