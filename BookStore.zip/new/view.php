<!DOCTYPE html>
<html>
<head>
<style>

body{
  background-image: url('it2.PNG');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}

h1{
color:white;
}

form {
align:center;
color:white;
}

#button {
width:100px;
height:50px;
border:0px;
background-color:#006e6b;
border-radius:15px;
color:white;
font-size:20px;


}

</style>

<script type="text/javascript">
  function validateForm() {
    var x1 = document.forms["myForm"]["author"].value;
    var x2 = document.forms["myForm"]["bookName"].value;


    if (x1 == "" ) {
      alert("Author name must be filled out");
      return false;
    }

    if (x2 == "" ) {
      alert("Book name must be filled out");
      return false;
    }




}

</script>
</head>
<body>

<form name="myForm"  onsubmit="return validateForm()" method="post">
<center><h1>View Book</h1></center>
<hr>
 <center>Book Name:<br><br> <center><input type="text" name="bookName"></center><br></center>
<center>Author Name:<br><br> <center><input type = "text" name="author" ></center></center>


<br><br><br>


  <center><input type="submit" name='submit' value="View" id="button"></center>
<br><br><br>
</form>

<?php
$name = $_POST['bookName'];
$author = $_POST['author'];


$servername = "localhost";
$username ="root";
$password ="as@ah221999";
$dname ="library";

$conn = new mysqli($servername, $username ,$password ,$dname);
if ($conn->connect_error){
	die ("Connection failed: ").$conn->connect_error;
}
else
{
	//echo "inserted";
}


$query = "SELECT * FROM `books` WHERE `bookname` = '$name' AND `author` = '$author'";
$result = mysqli_query($conn, $query);
$rownum = mysqli_num_rows($result);

echo '<center><table border="3" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">name</font> </td> 
          <td> <font face="Arial">category</font> </td> 
          <td> <font face="Arial">author</font> </td> 
          <td> <font face="Arial">price</font> </td> 
      </tr>';
    while ($rownum>0) {
		$row = mysqli_fetch_assoc($result);
        
        
        echo "<tr>";
		echo "<td>".$row["bookname"]."</td>";
		echo "<td>".$row["category"]."</td>";
		echo "<td>".$row["author"]."</td>";
		echo "<td>".$row["price"]."</td>";
                  
               
             echo "</tr> </center>"; 
	$rownum--;
    }
  
 
$conn->close();
	?>
	</body>
	</html>