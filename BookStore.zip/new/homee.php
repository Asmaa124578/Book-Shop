<?php
// Start the session
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script> 
$(document).ready(function(){
  $("button").click(function(){
    var div = $("div");  
    div.animate({left: '100px'}, "slow");
    div.animate({fontSize: '3em'}, "slow");
  });
});
</script> 
</head>

<body>
<style>
body{
  background-image: url('it.PNG');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
#button {
width:100px;
height:50px;
border:0px;
background-color:#006e6b;
border-radius:15px;
color:white;
font-size:20px;
}
</style>
<center><button id="button" >EAA</button> </center>

<div style="background:#009886;
height:100px;
width:200px;
color:white;
position:absolute;"> Welcome to our BOOK STORE!</div>



<br>
<br>


<pr> <font color="white"><center>"You know you’ve read a good book when you turn the last page and feel a little as if you have lost a friend" </center></font> </pr>
<br>
<br>
<form name="myForm" action="signup.php"  method="post">

<center><input type="submit" action="signup.php" value="Sign Up" id="button"></center>
<br>
</form>

<form name="myForm" action="login.php"  method="post">

<center><input type="submit" action="login.php" value="Log In" id="button"></center>
</form>

</body>
</html>