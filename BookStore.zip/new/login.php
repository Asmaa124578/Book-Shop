<?php
session_start();
include 'connect.php';
$error = "";
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $sql = "SELECT * FROM `users` WHERE `e-mail`='$email' AND `password` = '$pass'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) { // login successfully
        $_SESSION["email"] = $email;
        header('location:bootstrp.php'); // redirect user to profile.php
    } else {
        $error = "<h3 class='err'>Invail Email or Password</h3>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
  <style>
  .err{
    color:red;
  }
  body{
    background-image: url('it2.PNG');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: 100% 100%;
  }

  h1{
  color:white;
  }

  form {
  align:center;
  color:white;
  }

  #button {
  width:100px;
  height:50px;
  border:0px;
  background-color:#006e6b;
  border-radius:15px;
  color:white;
  font-size:20px;


  }

  </style>

</head>
<body>

<form name="myForm"  action="<?=$_SERVER['PHP_SELF']?>" onsubmit="return validateForm()" method="POST">
<center><h1></h1></center>
<hr>
 <center>E-mail:<br><br> <center><input type="e-mail" name="email"></center><br></center>
<center>Password:<br><br> <center><input type = "password" name="password" ></center></center>


<br><br><br>


  <center><input type="submit" name='submit' value="Log In" id="button"></center>
  <br>
  <center>
  <?php echo $error ?>
  </center>


</form>



<script type="text/javascript">
  function validateForm() {
    var x1 = document.forms["myForm"]["email"].value;
    var x2 = document.forms["myForm"]["password"].value;


    if (x1 == "" ) {
      alert(" email must be filled out");
      return false;
    }

    if (x2 == "" ) {
      alert("password must be filled out");
      return false;
    }
  }
  </script>
</body>
</html>