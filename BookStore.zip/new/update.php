<!DOCTYPE html>
<html>
<?php 
session_start();
include 'book.php';
?>

<head>
<style>

body{
  background-image: url('it2.PNG');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}

h1{
color:white;
}

form {
align:center;
color:white;
}

#button {
width:100px;
height:50px;
border:0px;
background-color:#006e6b;
border-radius:15px;
color:white;
font-size:20px;


}

</style>

<script type="text/javascript">
function validateForm() {
  var x2 = document.forms["myForm"]["oldname"].value;
  var x2 = document.forms["myForm"]["oldauthor"].value;
  
  
  if (x1 == "" ) {
    alert("Book id must be filled out");
    return false;
  }

  if (x2 == "" ) {
    alert("Book name must be filled out");
    return false;
  }
	

}

</script>
</head>
<body>

<form name="myForm"  onsubmit="return validateForm()" method="post">
<center><h1>Update Book</h1></center>
<hr>
 <!--Old Book id:<br><br> <input type="number_format" name="oldBookId"><br>
 <center>New Book id:<br><br> <center><input type="number_format" name="NewBookId"></center><br></center>
 -->
 <center>Old Book Name:<br><br> <center><input type="text" name="oldname"></center><br></center>
 <center>Old Author Name:<br><br> <center><input type="text" name="oldauthor"></center><br></center>
 <center>New Book Name:<br><br> <center><input type="text" name="newname"></center><br></center>
 <center>Book Category:<br><br><select name = "category">
 <option value="Drama" name="Drama"><br> Drama<br></option>
 <option value="Action" name="Action"><br> Action </option>
 <option value="Fiction" name="Fiction"><br>Fiction</option>
 <option value="Fiction" name="Fiction"><br>History</option>
 <option value="Fiction" name="Fiction"><br>Novel</option>
 <option value="Fiction" name="Fiction"><br>Poetry</option>
 </select>
<center>New Author:<br><br> <center><input type = "text" name="newauthor" ></center></center>
<center>New price:<br><br> <center><input type = "number_format" name="price" ></center></center>

<br><br><br>


  <center><input type="submit" name = "submit" value="update" id="button"></center>
</form>

<?php
if (isset($_POST['submit'])){
$ob1 = new book();

$oldname = $_POST['oldname'];
$oldauthor = $_POST['oldauthor'];


$ob1->setName($_POST['newname']);
$ob1->setCategory($_POST['category']);
$ob1->setAuthor($_POST['newauthor']);
$ob1->setPrice($_POST['price']);

$var1 = $ob1->getName();
$var2 = $ob1->getAuthor();
$var3 = $ob1->getCategory();
$var4 = $ob1->getPrice();

session_start();
$email = $_SESSION["email"];
$servername = "localhost";
$username ="root";
$password ="as@ah221999";
$dname ="library";

$conn = new mysqli($servername, $username ,$password ,$dname);
if ($conn->connect_error){
    die ("Connection failed: ").$conn->connect_error;
}
else
{
    //echo "inserted";
}

if(!empty($var1)){
	$sql = "UPDATE books SET bookname='$var1' WHERE bookname='$oldname' AND author = '$oldauthor' AND email = '$email'";
	
if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}
echo $var1;

}
if(!empty($var3)){
	$sql2 = "UPDATE books SET category='$var3' WHERE bookname='$oldname' AND author = '$oldauthor' AND email ='$email' ";
	
if ($conn->query($sql2) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}
echo $var3;
}
if(!empty($var2)){
	$sql3 = "UPDATE books SET author='$var2' WHERE bookname='$oldname' AND author = '$oldauthor' AND email ='$email' ";

	if ($conn->query($sql3) === TRUE) {
    echo "Record updated successfully";
	} else {
    echo "Error updating record: " . $conn->error;
	}
echo $var2;
}
if(!empty($var4)){
	$sql4 = "UPDATE books SET price='$var4' WHERE bookname='$oldname' AND author = '$oldauthor' AND email ='$email'";
	if ($conn->query($sq4) === TRUE) {
    echo "Record updated successfully";
	} else {
    echo "Error updating record: " . $conn->error;
	}
	echo $var4;
}
echo "hereeeeeeeeeeeeeee";

$conn->close();
}
?>

</body>
</html>